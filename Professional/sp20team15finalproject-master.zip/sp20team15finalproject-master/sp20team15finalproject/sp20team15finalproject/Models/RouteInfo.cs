﻿//using Microsoft.AspNetCore.Identity;
//using System;
//using System.Collections.Generic;
//using System.ComponentModel.DataAnnotations;
//using System.ComponentModel.DataAnnotations.Schema;
//using System.Linq;
//using System.Threading.Tasks;




//NO LONGER IN USE!!!! STORED ON FLIGHTS.











//namespace sp20team15finalproject.Models
//{
//    public class RouteInfo
//    {
//        [Display(Name = "Route Info ID")]
//        public Int32 RouteInfoID { get; set; }

//        [Display(Name = "Mileage")]
//        [Required(ErrorMessage = "Mileage is Required")]
//        public Int32 Mileage { get; set; }

//        [Display(Name = "Flight Time")]
//        [Required(ErrorMessage = "Flight Time is Required")]
//        public String FlightTime { get; set; }

//        public City DepCity { get; set; }

//        public City ArrCity { get; set; }
//    }
//}
